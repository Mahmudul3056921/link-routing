#!/usr/bin/python

'''

Topology
1. Partial mesh with multipath



          / s1------s6    /s8 \
         /           \   /     \ 
        /             \ /       \ 
h1 ---s2------s4 ----s5 ------s10 ----h2
        \             / \       /  
         \           /   \     /  
          \ s3------s7    \ s9/
        
'''


from mininet.topo import Topo
from mininet.net import Mininet
from mininet.log import setLogLevel
from mininet.cli import CLI
from mininet.node import RemoteController,OVSKernelSwitch
from time import sleep


class Multipathtopo(Topo):
    "Multipathtopo."

    def build(self):
        s1 = self.addSwitch('s1', cls=OVSKernelSwitch)
        s2 = self.addSwitch('s2', cls=OVSKernelSwitch)
        s3 = self.addSwitch('s3', cls=OVSKernelSwitch)
        s4 = self.addSwitch('s4', cls=OVSKernelSwitch)
        s5 = self.addSwitch('s5', cls=OVSKernelSwitch)
        s6 = self.addSwitch('s6', cls=OVSKernelSwitch)
        s7 = self.addSwitch('s7', cls=OVSKernelSwitch)

        s8 = self.addSwitch('s8', cls=OVSKernelSwitch)
        s9 = self.addSwitch('s9', cls=OVSKernelSwitch)
        s10 = self.addSwitch('s10', cls=OVSKernelSwitch)

        h1 = self.addHost('h1', mac="00:00:00:00:00:01", ip="192.168.1.1/24")
        h2 = self.addHost('h2', mac="00:00:00:00:00:02", ip="192.168.1.2/24")

        self.addLink(s2, s3)
        self.addLink(s1, s2)

        self.addLink(s2, s4)
        self.addLink(s4, s5)

        self.addLink(s1, s6)
        self.addLink(s3, s7)

        self.addLink(s5, s6)
        self.addLink(s5, s7)

        self.addLink(s5, s8)
        self.addLink(s5, s9)

        self.addLink(s5, s10)

        self.addLink(s8, s10)
        self.addLink(s9, s10)

        self.addLink(h1, s2)
        self.addLink(h2, s10)



if __name__ == '__main__':
    setLogLevel('info')
    topo = Multipathtopo()
    c1 = RemoteController('c1', ip='127.0.0.1')
    net = Mininet(topo=topo, controller=c1)
    net.start()
    net.staticArp()
    # get the host objects
    h1 = net.get('h1')
    h2 = net.get('h2')
    h1.cmd('ping -c 5 -W 0.2 192.168.1.2 &')
    h2.cmd('ping -c 5 -W 0.2 192.168.1.1 &')   
    CLI(net)
    net.stop()
